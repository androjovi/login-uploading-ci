<div class="modal fade" id="uploadBg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Ganti background</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url('user/proses_ganti'); ?>" method="post" enctype="multipart/form-data">
          <div class="container-fluid">
            <div class="form-group">
              <label for="exampleInputFile">Pilih gambar</label>
              <input type="file" name="file2">
              <p class="help-block">Ukuran maksimun : 2000kb</p>
              <p class="help-block">Panjang maksimun : 1366px</p>
              <p class="help-block">Lebar maksimun : 728px</p>
              <button class="btn btn-primary" type="submit">Upload</button>
            </div>
          </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
      </div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Pengaturan</h4>
      </div>
      <div class="modal-body">
        <a class="btn btn-primary" href="<?php echo base_url('user/pengaturan_bg') ?>" role="button"><i class="fa fa-trash">&nbsp; </i>Matikan background</a>
        <a class="btn btn-primary" href="<?php echo base_url('user/pengaturan_fp') ?>" role="button"><i class="fa fa-trash">&nbsp; </i>Hapus foto profil</a>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid">
  <?php foreach($user as $value): ?>
  <div class="row">
  <div class="col-xs-6 col-sm-3">
    <!-- <h5>Selamat datang <?php echo $value->nama_lengkap; ?></h5>-->
    <div class="panel panel-primary">
      <div class ="panel-heading">Profil</div>
      <div class="panel-body">
    <?php if (null ==!$value->foto_profil) { ?>
      <center><a href="./upload_image/<?php echo $value->foto_profil; ?>" title="Lihat gambar"><img src="./upload_image/<?php echo $value->foto_profil; ?>" style="width:50%;height:20%;" class="img-thumbnail" ></a></center>
      <p style="text-align:center;"><a href="<?php echo base_url('user/upload_foto'); ?>">Ganti foto profil</a></p>
      <?php }else{ ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<i class="fa fa-camera">&nbsp; </i>Belum ada foto profil <a href="<?php echo base_url('user/upload_foto'); ?>" class="alert-link">Upload</a></div>
      <?php } ?>
<?php
switch ($value->jenis_kelamin){
  case 'l' : $z = "Laki-laki";  break;
  case 'p' : $z = "Perempuan";  break;
}
?>
  <p>User id       : <?php  echo $value->id; ?></p>
  <p>Nama lengkap  : <?php  echo $value->nama_lengkap; ?></p>
  <p>Username      : <?php  echo $value->username; ?></p>
  <p>Alamat rumah  : <?php  echo $value->alamat_rumah; ?></p>
  <p>Jenis kelamin : <?php  echo $z; ?></p>
  <p>Email         : <?php  echo $value->email; ?></p>
  <p>Bergabung sejak  : <?php  echo $diff_hari; ?>&nbsp;hari lalu</p>

    </div>
  </div>
  <div class="well well-sm">
    <?php
    switch ($value->jumlah_kontribusi){
      case '0' : $m = "<a href='".base_url('')."'>Upload Project</a>";break;
      default : $m = $value->jumlah_kontribusi;break; //Jika nilai ada maka default dijalankan
    }
    ?>
    <p>Jumlah yang kamu upload : <?php echo $m; ?> </p>
  <?php endforeach; ?>
  </div>
</div>
  <div class="col-xs-6 col-sm-3">
    <div class="panel panel-info">
      <div class ="panel-heading">Aksi</div>
      <div class="panel-body">
        <div class="navbar-btn">
    <a class="btn btn-default center-block" href="<?php echo base_url('user/edit'); ?>" role="button">Edit profile</a>
    <a class="btn btn-default center-block" href="<?php echo base_url('user/profil'); ?>" role="button">Lihat profile</a>
    <a class="btn btn-default center-block" href="<?php echo base_url('user/list_project'); ?>" role="button">Edit project</a>
    <a class="btn btn-default center-block" href="<?php echo base_url('user/tambah_project') ?> " role="button">Upload project</a>
    <a class="btn btn-default center-block" href="#" role="button">Lihat project</a>
  </div>
</div>
</div>
<div class="dropdown">
  <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
    Aksi lain
    <span class="caret"></span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
    <li><a href="#" data-toggle="modal" data-target="#myModal">Pengaturan</a></li>
    <li role="separator" class="divider"></li>
    <li><a href="<?php echo base_url('logout') ?>">Keluar</a></li>
  </ul>
</div>
<br>
<div class="alert alert-success alert-dismissible" role="alert" style="">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
<i class="fa fa-camera-picture-o">&nbsp; </i>Ganti background belakang <a href="#" data-toggle="modal" data-target="#uploadBg" class="alert-link">Ganti</a></div>


</div>
  <div class="col-xs-6 col-sm-6">
    <div class="panel panel-success">
      <div class ="panel-heading">Sekilas yang kamu upload</div>
      <div class="panel-body">

    <table class="table table-hover">
      <thead>
<tr>
    <th>No</th>
    <th>Nama</th>
    <th>Deskripsi</th>
</tr>
</thead>
 <?php foreach($query as $value_project) : ?>
  <tr>
    <tbody>
    <td><?php echo $value_project->no; ?></td>
    <td><?php echo $value_project->nama_project; ?></td>
    <td><a href="./upload_file/<?php echo $value_project->name_file; ?>" id="ahref"><?php echo $value_project->name_file; ?></a></td>
  </tr>
<?php endforeach; ?>
</table>
<?php echo $halaman; ?></div>
</div>

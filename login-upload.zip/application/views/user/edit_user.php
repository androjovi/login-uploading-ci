<?php foreach($get_data as $value ): ?>
<form class="form-horizontal" action="<?php echo base_url('user/proses_edit'); ?>" method="post">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Nama lengkap<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="text" name="nama_lengkap" class="form-control" id="inputEmail3" placeholder="<?php echo $value->nama_lengkap; ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Username<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="text" name="user" class="form-control" id="inputPassword3" placeholder="<?php echo $value->username; ?>" disabled="true">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Alamat email<b class="text-danger"></b></label>
    <div class="col-sm-10">
      <input type="text" name="email" class="form-control" id="inputPassword3" placeholder="<?php echo $value->email; ?>">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Alamat rumah</label>
    <div class="col-sm-10">
      <textarea class="form-control" name="adress" rows="5" placeholder="<?php echo $value->alamat_rumah; ?>"></textarea>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Jenis kelamin<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <select class="form-control" id="jk" name="jenis_kelamin">
        <option value="l">Pria</option>
        <option value="p">Wanita</option>
      </select>
      <a class="btn btn-link" href="<?php echo base_url('user/ganti_password') ?>" role="button">Ganti password</a>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Edit</button>
      <button type="reset" class="btn btn-danger">Hapus</button>
      <a class="btn btn-info" href="<?php echo base_url('user') ?>" role="button">Kembali</a>
    </div>
  </div>
</form>
<?php endforeach; ?>

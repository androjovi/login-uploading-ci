<?php foreach ($get_data_user as $value) : ?>
<div class="container">
        <div class="fb-profile">
            <img align="left" class="fb-image-lg" src="http://lorempixel.com/850/280/nightlife/5/" alt="Profile image example"/>
            <img align="left" class="fb-image-profile thumbnail" src="<?php echo base_url('upload_image/');
            if ($value->foto_profil)
            {
            echo $value->foto_profil;
            }
            else{
            echo "noneNone3000.jpg";
          }
            ?>"
             alt="Profile image example"/>
            <div class="fb-profile-text">
                <h1><?php echo $value->nama_lengkap; ?> (<?php echo $value->username; ?>)</h1>
                <p><?php if ($value->bio == FALSE){echo "Tambahkan bio";}else{echo $value->bio;} ?></p>
                <p>Kontribusi <?php echo $value->jumlah_kontribusi;  ?></p>
                <p>Mengikuti</p>
                <p>Diikuti</p>
            </div>
        </div>
    </div> <!-- /container -->
  </body>
</html>
<?php endforeach; ?>

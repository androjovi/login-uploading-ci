<div class="container-fluid">
<form action="<?php echo base_url('user/proses_tambah_project'); ?>" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleInputEmail1">Nama project</label>
    <input type="text" name="name_project" class="form-control" id="exampleInputEmail1" placeholder="Name of project">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Link project</label>
    <input type="text" name="link" class="form-control" id="exampleInputPassword1" placeholder="Link of project">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Deskripsi project</label>
    <input type="text" name="des_project" class="form-control" id="exampleInputPassword1" placeholder="Descrption of project">
  </div>
  <div class="form-group">
    <label>File input</label>
    <input type="file" name="file_input">
    <p class="help-block">File format .Zip .Rar</p>
    <p class="help-block">Max size 5mb</p>
  </div>
  <button type="submit" class="btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i> Tambah</button>
  <button type="reset" class="btn btn-danger"><i class="fa fa-eraser" aria-hidden="true"></i> Hapus</button>
  <a class="btn btn-link" href="<?php echo base_url('user') ?>" role="button"><< Kembali</a>
</form>

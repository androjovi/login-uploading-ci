<form action="<?php echo base_url('user/proses_upload_gambar'); ?>" method="post" enctype="multipart/form-data">
<div class="container-fluid">
<div class="form-group">
<label for="exampleInputFile">Pilih gambar</label>
<input type="file" name="file">
<p class="help-block">Ukuran maksimun : 2000kb</p>
<p class="help-block">Panjang maksimun : 1366px</p>
<p class="help-block">Lebar maksimun : 728px</p>
<button class="btn btn-primary" type="submit">Upload</button>
</div>
</div>

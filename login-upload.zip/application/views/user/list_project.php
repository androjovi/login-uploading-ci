
<a class='btn btn-info' href='<?php echo base_url('user'); ?>' role='button'>Kembali</a>
  <div class="table-responsive">
    <table class="table">
      <thead>
      <tr>
        <th>Nama</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($query as $p): ?>
      <tr>
        <td><?php echo $p->nama_project; ?></td>
        <td><?php echo anchor("user/edit_project/".$p->no."",'Edit',array('class'=>'btn btn-primary btn-xs','role'=>'button')); ?> <?php echo anchor("user/del/".$p->no."",'Hapus',array('class'=>'btn btn-danger btn-xs','role'=>'button')); ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    </table>
    <?php echo $halaman; ?>
  </div>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    
    <title>Selamat datang <?php echo $this->session->userdata('data_login'); ?></title>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
     <link rel="stylesheet" href="<?php  echo base_url();?>assets/bootstrap.min.css">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
     <link href="<?php echo base_url('assets/prof.css'); ?>" rel="stylesheet" type="text/css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script
    <script src="https://use.fontawesome.com/2c3b2f6f61.js"></script>
    <link rel="stylesheet" href="<?php  echo base_url();?>assets/sweetalert.css">
    <script src="<?php echo base_url(); ?>assets/sweetalert.min.js"></script>
    <?php
    if (!$this->session->userdata('status_login')) {
      echo "<script>alert('Anda belum masuk silahkan masuk')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('login')."'>";
      die();
    }
      ?>
      <style>
      .form-control{
        width:50%;
      }
      </style>
  </head>
  <?php foreach($user as $value): ?>
  <body style="background:url('<?php echo base_url(); ?>./upload_bg/<?php echo $value->foto_bg; ?>')">
  <?php endforeach; ?>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
        <img alt="Brand" src="<?php echo base_url();?>assets/hd-inter.png" style="width:30px;height:30px;">
      </a>
      <?php if ($this->session->userdata('status_login')){ ?>
        <a class='btn btn-danger navbar-btn' href='<?php echo base_url(); ?>logout' role='button'>Logout</a>
        <p class='navbar-text navbar-right navbar-btn'>Signed in as <a href='' class='navbar-link'><?php echo $this->session->userdata('data_login'); ?></a></p>
        <a class='btn btn-link' href='<?php echo base_url(''); ?>' role='button'>Halaman depan</a>
      <?php }else{
        echo "<a href='".base_url('login')."'<button type='button' class='btn btn-primary navbar-btn'>Sign in</button></a>";
      }
      ?>
    </div>
    <p class="navbar-text navbar-right">Render time {elapsed_time}</p>
    <p class="navbar-text navbar-right">Usage memory {memory_usage}</p>
    <p class="navbar-text navbar-right"><?php echo date('r'); ?></p>
  </div>
</nav>

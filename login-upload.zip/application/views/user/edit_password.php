<link rel="stylesheet" href="<?php  echo base_url();?>assets/bootstrap.min.css">
<style>
.cwxxasyz{
  margin: 100px auto;
  text-align: center;
}
</style>
<div class="cwxxasyz">
<form class="form-inline" action="<?php echo base_url('user/proses_ganti_pass'); ?>" method="post">
  <div class="form-group">
    <label class="sr-only" for="exampleInputEmail3">Email address</label>
    <input type="password" name="pass" class="form-control" id="exampleInputEmail3" placeholder="Password baru">
  </div>
  <div class="form-group">
    <label class="sr-only" for="exampleInputPassword3">Password</label>
    <input type="password" name="re_pass" class="form-control" id="exampleInputPassword3" placeholder="Ulangi password">
  </div>
  <button type="submit" class="btn btn-primary">Ganti</button>
  <a class="btn btn-info" href="<?php echo base_url('user') ?>" role="button">Kembali</a>
  <?php echo validation_errors(); ?>

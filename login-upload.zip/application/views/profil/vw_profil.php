<?php foreach ($user as $value) : ?>
<div class="container">
        <div class="fb-profile">
            <img align="left" class="fb-image-lg" src="http://lorempixel.com/850/280/nightlife/5/" alt="Profile image"/>
              <img align="left" class="fb-image-profile thumbnail" src="<?php echo base_url('upload_image/'); if ($value->foto_profil){echo $value->foto_profil;}else{echo "noneNone3000.jpg";}?>" alt="Profile image">
            <div class="fb-profile-text">
                <h1><?php echo $value->nama_lengkap; ?> (<?php echo $value->username; ?>)</h1>
                <p><?php if ($value->bio == FALSE){echo"";}else{echo $value->bio;} ?></p>
                <p>Jumlah repository : <b><?php echo $value->jumlah_kontribusi;  ?></p></b>
            </div>
        </div>
    </div> <!-- /container -->
<hr></hr>
<h2 style="text-align:center;">List Repository</h2>
<div class="container">
<table class="table">
  <thead>
  <tr>
    <th>Nama project</th>
    <th>Deksripsi</th>
    <th>Source code</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td><?php echo $value->nama_project; ?></td>
    <td><?php echo $value->deskripsi_project; ?></td>
    <?php
    if ($this->session->userdata('status_login')){
      echo "<td><a href='".base_url('upload_file/')."{$value->name_file}'>$value->name_file</a></td>";
    }else{
      echo "<td><a class='btn btn-link' href='".base_url('login')."' role='button'>Masuk untuk lihat</a></td>";
    }
    ?>
  </tr>
</tbody>
</table>
</body>
</html>
<?php endforeach; ?>

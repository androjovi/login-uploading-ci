<form class="form-horizontal" action="<?php echo base_url(); ?>login/proses_daftar" method="post">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Nama lengkap<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="text" name="nama_lengkap" class="form-control" id="inputEmail3" placeholder="Nama lengkap">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Username<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="text" name="user" class="form-control" id="inputPassword3" placeholder="Username">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Password<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="password" name="pass" class="form-control" id="inputEmail3" placeholder="Password">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Ulangi password<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <input type="password" name="re_pass" class="form-control" id="inputPassword3" placeholder="Ulangi password">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Email valid</label>
    <div class="col-sm-10">
      <input type="text" name="email" class="form-control" id="inputPassword3" placeholder="Email">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Alamat rumah</label>
    <div class="col-sm-10">
      <textarea class="form-control" name="adress" rows="5"></textarea>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Jenis kelamin<b class="text-danger"> *</b></label>
    <div class="col-sm-10">
      <select class="form-control" id="jk" name="jenis_kelamin">
        <option value="l">Pria</option>
        <option value="p">Wanita</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <?php if (null ==! validation_errors()) { ?>
        <div class="alert alert-danger" role="alert" style="width:30%;">
          <?php echo validation_errors(); ?>
        </div>

        <?php } ?>
      <button type="submit" class="btn btn-primary">Daftar</button>
      <button type="reset" class="btn btn-danger">Hapus</button>

      <p>Punya akun ?<a class="btn btn-link" href="<?php echo base_url('login/masuk'); ?>" role="button">Gausah daftar njing</a></p>
    </div>
  </div>
</form>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Selamat datang</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!--
    Offline mode
    <link rel="stylesheet" href="<?php  echo base_url();?>assets/bootstrap.min.css">
   -->
    <link rel="stylesheet" href="<?php  echo base_url();?>assets/sweetalert.css">
    <script src="<?php echo base_url(); ?>assets/sweetalert.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style>
    .form-control{
      width:60%;
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
        <img alt="Brand" src="<?php echo base_url();?>assets/hd-inter.png" style="width:30px;height:30px;">
      </a>
      <?php if ($this->session->userdata('status_login')){
        echo "<a class='btn btn-danger' href='".base_url('login/keluar')."' role='button'>Logout</a>";
        echo "<p class='navbar-text navbar-right'>Signed in as <a href='' class='navbar-link'>{$this->session->userdata('data_login')}</a></p>";
      }else{
        echo "<a href='".base_url('login')."'<button type='button' class='btn btn-primary navbar-btn'>Sign in</button></a>";
      }
      ?>
    </div>
<!--    <p class="navbar-text navbar-right">Render time {elapsed_time}</p> -->
  </div>
</nav>
  </body>
</html>

<div class="container">
<form class="form-horizontal" action="<?php echo base_url(); ?>login/masuk" method="post">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="user" id="inputEmail3" placeholder="Username anda" style="width:700px;">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="pass" id="inputPassword3" placeholder="Password anda" style="width:700px;">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <?php if (null ==! validation_errors()) { ?>
      <div class="alert alert-danger" role="alert" style="width:30%;">
        <?php echo validation_errors(); ?>
      </div>
      <?php } ?>
      <?php if (isset($pesan)) { ?>
        <div class="alert alert-danger" role="alert" style="width:30%;">
          <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
          <span class="sr-only">Error:</span>
          Username atau password salah
        </div>
        <?php } ?>
      <button type="submit" name="submit" class="btn btn-primary">Sign in</button>
      <button type="reset" class="btn btn-danger">Hapus</button>
      <br><br>
      <p>Tidak punya akun ?<a class="btn btn-link" href="<?php echo base_url('login/daftar'); ?>" role="button">Daftar sekarang</a></p>
    </div>
  </div>
</div>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Selamat datang</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!--
    Offline mode
    <link rel="stylesheet" href="<?php  echo base_url();?>assets/bootstrap.min.css">
   -->
    <link href="<?php echo base_url('assets/prof.css'); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php  echo base_url();?>assets/sweetalert.css">
    <script src="<?php echo base_url(); ?>assets/sweetalert.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style>
    .btn-andro{
      border:1px solid red;
      background-color: rgb(255, 255, 255);
    }
    </style>
    <script>
    $(document).ready(function () {
    $("#myModal").modal("show").on('shown.bs.modal', function () {
        $(".modal").css('display', 'block');
    })
});
    </script>
  </head>
  <body>
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
       <span class="sr-only">Toggle navigation</span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
     </button>

   </div>
   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
        <img alt="Brand" src="<?php echo base_url();?>assets/hd-inter.png" style="width:30px;height:30px;">
      </a>
      <?php if ($this->session->userdata('status_login')){
        echo "<a class='btn btn-danger navbar-btn' href='".base_url('logout')."' role='button'>Logout</a>";
        echo "<p class='navbar-text navbar-right'>Signed in as {$this->session->userdata('data_login')}</p>&nbsp;";
        echo "<a class='btn btn-info' href='".base_url('user')."' role='button'>Dashboard</a>";
      }else{
        echo "<a href='".base_url('login')."'<button type='button' class='btn btn-primary navbar-btn'>Sign in</button></a>";
      }
      ?>
      <form class="navbar-form navbar-left" action="<?php echo base_url('cari'); ?>" method="get">
        <div class="form-group">
          <input type="text" name="sc" class="form-control" placeholder="Search projects">
        </div>
        <button type="submit" class="btn btn-success"><span class="glyphicon glyphicon-search" aria-hidden="true"></span> Cari</button>
      </form>
    </div>
  </div>
</div>
</div>
</nav>

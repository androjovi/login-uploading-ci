<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">prt Sc Sys Rq</h4>
      </div>
      <div class="modal-body">
        <h4>Web apa ini ?</h4>
        <p>Website dimana kamu bisa mengirim, menyimpan, membagi project kamu dalam bentuk zip/rar </h4>
        <h4>Fitur yang ada di web ini : </h4>
        <ul>
          <li>Login daftar dengan hash user password, bahkan admin pun tidak tau password user</li>
          <li>User bisa melakukan <ul><li>Upload foto profil</li><li>Mengganti background web</li><li>Upload file</li><li>Menambah, mengedit, menghapus repository</li><li>Mengedit profil</li></ul></li>
          <li>Memakai codeigniter yang terkenal dengan keamannya</li>
          <li>Menggunakan Bootstrap dan Jquery</li>
        </ul>
        <h4>Spesifikasi</h4>
        <ul>
          <li>PHP 7.1.1</li>
          <li>Codeigniter 3.1.5</li>
          <li>Bootstrap 3.3.7</li>
          <li>Jquery 3.2.1</li>
          <li>Database driver : mysqli</li>
        </ul>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="container-fluid">
<table class="table table-hover">
  <thead>
    <tr>
      <th>Nama project</th>
      <th>Source code</th>
      <th>Deskripsi</th>
      <th>Pengunggah</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($query as $v) : ?>
    <tr>
      <td><?php echo $v->nama_project; ?></td>
      <td><a href="<?php echo base_url("upload_file/$v->name_file"); ?>">Download</a> </td>
      <td><?php echo $v->deskripsi_project; ?></td>
      <td><a href="<?php echo base_url("profil/user/$v->uploader"); ?> "><?php echo $v->uploader; ?></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<div style="text-align:center;"><?php echo $halaman; ?></div>
</div>
</body>
</html>

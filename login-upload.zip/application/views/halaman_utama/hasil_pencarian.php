<div class="container-fluid">
  <?php
  if (!$valid){
    echo "<a class='btn btn-info' href='".base_url('')."' role='button'>Halaman depan</a>";
    echo "<h3>Tidak ada data yang ingin dicari</h3>";
  }else{
    ?>
    <a class='btn btn-info' href='<?php echo base_url(''); ?>' role='button'>Halaman depan</a>
<?php
if ($total_rows > 0){
  echo "<h3>Data ditemukan : <i>$total_rows</i></h3>";
 ?>
<table class="table table-hover">
  <thead>
    <tr>
      <th>Nama</th>
      <th>Nama project</th>
      <th>Deskripsi</th>
      <th>Pengunggah</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($query as $v) : ?>
    <tr>
      <td><?php echo $v->nama_project; ?></td>
      <td><a href="<?php echo base_url("upload_file/$v->name_file"); ?>">Download</a> </td>
      <td><?php echo $v->deskripsi_project; ?></td>
      <td><a href="<?php echo base_url("profil/user/$v->uploader"); ?> "><?php echo $v->uploader; ?></a></td>
    </tr>
  <?php endforeach ?>
  </tbody>
</table>
<div style="text-align:center;"><?php echo $halaman; ?></div>
<?php }else{
  echo "<h3>Data tidak ditemukan, Coba ulangi</h3>";
  }
} ?>
</div>

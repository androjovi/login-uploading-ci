<?php
//Sesi sudah dimulai
ob_start();
class User extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('user_model');
    $this->load->library(array('form_validation','session'));
    if (!$this->session->userdata('status_login')){
      echo "<script>alert('Anda belum masuk')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('login')."'>";
      die();
    }
  }
  function index($id=NULL){
    $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );
    $sesi_user_project=array(
      'uploader' => $this->session->userdata('data_login')
    );
    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    foreach ($data['user'] as $value) {
      $awal=date_create($value->tanggal_buat);
      $akhir=date_create();
      $selisih=date_diff($awal,$akhir);
    }
    $data['diff_hari']=$selisih->days;

    $this->load->library('pagination');
    $total_row=$this->user_model->get_rows_project($sesi_user_project,'project_upload');
    $config['base_url']   =base_url()."user/index";
    $config['total_rows'] =$total_row;
    $config['per_page']   =5;
    $config['first_page'] ="Awal";
    $config['last_page']  ="Akhir";
    $config['next_page']  ='>>';
    $config['last_page']  ='<<';
    $config['full_tag_open'] = '<ul class="pagination">';
    $config['full_tag_close'] = '</ul>';
    $config['first_link'] = '&laquo; First';
    $config['first_tag_open'] = '<li class="prev page">';
    $config['first_tag_close'] = '</li>';
    $config['last_link'] = 'Last &raquo;';
    $config['last_tag_open'] = '<li class="next page">';
    $config['last_tag_close'] = '</li>';
    $config['next_link'] = 'Next &rarr;';
    $config['next_tag_open'] = '<li class="next page">';
    $config['next_tag_close'] = '</li>';
    $config['prev_link'] = '&larr; Prev';
    $config['prev_tag_open'] = '<li class="prev page">';
    $config['prev_tag_close'] = '</li>';
    $config['cur_tag_open'] = '<li class="current"><a href="">';
    $config['cur_tag_close'] = '</a></li>';
    $config['num_tag_open'] = '<li class="page">';
    $config['num_tag_close'] = '</li>';
    $this->pagination->initialize($config);
    $data['halaman']      =$this->pagination->create_links();
    $data['query']        =$this->user_model->get_project($config['per_page'],$id,'project_upload');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/user',$data);
  }
  function upload_foto(){
    $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );
    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/ganti_fp');
  }
  function proses_upload_gambar(){
    $this->load->library('upload');
    $config['upload_path']   = './upload_image/';
    $config['allowed_types'] = 'jpg|png|jpeg|bmp|';
    $config['max_size']      = '2000';

    $this->upload->initialize($config);
    if ($this->upload->do_upload('file')){
      $this->load->model('upload_model');
      $data_file=array(
        'foto_profil' => $this->upload->data('file_name')
      );
      $this->upload_model->simpan_gambar($data_file);
      echo "<script>alert('Berhasil melakukan upload')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('user')."'>";
    }else{
      echo "<pre>";
      echo print_r($this->upload->data());
      echo $this->upload->display_errors();
    }
  }
  function ganti_bg(){
    $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );

    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/ganti_bg');
  }
  function proses_ganti(){
    $this->load->library('upload');
    $config['upload_path']   = './upload_bg/';
    $config['allowed_types'] = 'jpg|png|jpeg|png';
    $config['max_size']      = '5000';
    $config['max_width']     = '4000';
    $config['min_width']     = '720';
    $config['max_height']    = '4000';
    $config['min_height']    = '500';
    $this->upload->initialize($config);

    if ($this->upload->do_upload('file2')){
      $data_bg=array(
        'foto_bg'  => $this->upload->data('file_name')
      );
      $this->user_model->change_bg($data_bg,'user_login');
      echo "<script>alert('Berhasil melakukan upload')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('user')."'>";
    }else{
      echo $this->upload->display_errors();
    }
  }
  function pengaturan_bg(){
    $data_bg_white=array(
      'foto_bg'   => NULL
    );
    $this->user_model->change_bg_white($data_bg_white,'user_login');
    echo "<script>alert('Berhasil mengganti background')</script>";
    echo "<meta http-equiv='refresh' content='0;url=".base_url('user')."'>";
  }
  function pengaturan_fp(){
    $data_fp_none=array(
      'foto_profil' => NULL
    );
    $this->user_model->change_fp_none($data_fp_none,'user_login');
    echo "<script>alert('Berhasil menghapus foto profil')</script>";
    echo "<meta http-equiv='refresh' content='0;url=".base_url('user')."'>";
  }
  function edit(){
    $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );

    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    $data["get_data"]=$this->user_model->get_data_user($sesi_user,'user_login');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/edit_user',$data);
  }
  function proses_edit(){
    $this->form_validation->set_rules("nama_lengkap","Nama lengkap","max_length[50]|min_length[2]");
    $this->form_validation->set_rules("adress","Alamat rumah","max_length[50]");
    $this->form_validation->set_rules("jenis_kelamin","Jenis kelamin","required");
    $this->form_validation->set_rules("email","Email","valid_email|max_length[50]");
    if ($this->form_validation->run()){
      if (null ==! $this->input->post('nama_lengkap')){
        $data_nama=array(
          'nama_lengkap' => $this->input->post('nama_lengkap')
        );
        $cz=$this->user_model->edit_user($data_nama,'user_login');
      }
      if (null ==! $this->input->post('adress')){
        $data_alamat=array(
          'alamat_rumah' => $this->input->post('adress')
        );
        $cz=$this->user_model->edit_user($data_alamat,'user_login');
      }
      if (null ==! $this->input->post('jenis_kelamin')){
        $data_kel=array(
          'jenis_kelamin' => $this->input->post('jenis_kelamin')
        );
        $cz=$this->user_model->edit_user($data_kel,'user_login');
      }
      if (null ==! $this->input->post('email')){
        $data_kel=array(
          'email' => $this->input->post('email')
        );
        $cz=$this->user_model->edit_user($data_kel,'user_login');
      }
    }else{
      echo "<script>alert('Coba ulangi')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('user/edit')."'>";
    }
    if ($cz !== FALSE){
      echo "<script>alert('Berhasil mengubah data')</script>";
      echo "<meta http-equiv='refresh' content='0;url=".base_url('user/edit')."'>";
    }
  }
  function profil(){
    $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );

    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    $data["get_data"]=$this->user_model->get_data_user($sesi_user,'user_login');
    $data['get_data_user']=$this->user_model->get_data_user($sesi_user,'user_login');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/profil',$data);
  }
  function tambah_project(){
  $sesi_user=array(
      'username' => $this->session->userdata('data_login')
    );

    $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
    $data["get_data"]=$this->user_model->get_data_user($sesi_user,'user_login');
    $this->load->view('user/navbar_user',$data);
    $this->load->view('user/tambah_project');
  }
  function proses_tambah_project(){
    $this->form_validation->set_rules('name_project','Nama project','required|max_length[30]');
    $this->form_validation->set_rules('link','Link project','required|max_length[30]');
    $this->form_validation->set_rules('des_project','Deskripsi','required|max_length[40]');
    if ($this->form_validation->run()){
      $this->load->library('upload');
      $config['upload_path']   ='./upload_file/';
      $config['allowed_types'] ='rar|zip';
      $config['max_size']      ='5000';
      $this->upload->initialize($config);
      if ($this->upload->do_upload('file_input')){
        $time=date('Hissi');
        $dff=substr($this->input->post('nama_project'),0,1);
        $add_no=$dff.str_shuffle($time);
        $data=array(
          'no'                => $add_no,
          'nama_project'      => $this->input->post('name_project'),
          'deskripsi_project' => $this->input->post('des_project'),
          'link_project'      => $this->input->post('link'),
          'uploader'          => $this->session->userdata('data_login'),
          'name_file'         => $this->upload->data('file_name'),
        );
        $adding=$this->user_model->add_project_user($data,'project_upload');
        if ($adding !==FALSE){
          $get_kontri=$this->user_model->get_kontribusi();
          foreach ($get_kontri as $val) {
            $dt=$val->jumlah_kontribusi;
          }
          $add=$dt++;
          $data_add=array(
            'jumlah_kontribusi' => $dt
          );
          $this->user_model->add_kontribusi($data_add,'user_login');
          echo "<script>alert('NO : ".$add_no." /// Berhasil')</script>";
          echo "<meta http-equiv='refresh' content='0;url=".base_url('user')."'>";
        }else{
          echo "Tidak";
        }
      }else{
        echo $this->upload->display_errors();
      }
    }else{
      echo validation_errors();
    }
  }
  function list_project($id=NULL){
    $sesi_user=array(
        'username' => $this->session->userdata('data_login')
      );
      $sesi_user_project=array(
        'uploader' => $this->session->userdata('data_login')
      );
      $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
      $this->load->library('pagination');
      $total_row=$this->user_model->get_rows_project($sesi_user_project,'project_upload');
      $config['base_url']   =base_url()."user/list_project/";
      $config['total_rows'] =$total_row;
      $config['per_page']   =5;
      $config['first_page'] ="Awal";
      $config['last_page']  ="Akhir";
      $config['next_page']  ='>>';
      $config['last_page']  ='<<';
      $config['full_tag_open'] = '<ul class="pagination">';
      $config['full_tag_close'] = '</ul>';
      $config['first_link'] = '&laquo; First';
      $config['first_tag_open'] = '<li class="prev page">';
      $config['first_tag_close'] = '</li>';
      $config['last_link'] = 'Last &raquo;';
      $config['last_tag_open'] = '<li class="next page">';
      $config['last_tag_close'] = '</li>';
      $config['next_link'] = 'Next &rarr;';
      $config['next_tag_open'] = '<li class="next page">';
      $config['next_tag_close'] = '</li>';
      $config['prev_link'] = '&larr; Prev';
      $config['prev_tag_open'] = '<li class="prev page">';
      $config['prev_tag_close'] = '</li>';
      $config['cur_tag_open'] = '<li class="current"><a href="">';
      $config['cur_tag_close'] = '</a></li>';
      $config['num_tag_open'] = '<li class="page">';
      $config['num_tag_close'] = '</li>';
      $this->pagination->initialize($config);
      $data['halaman']      =$this->pagination->create_links();
      $data['query']        =$this->user_model->get_project($config['per_page'],$id,'project_upload');
      $this->load->view('user/navbar_user',$data);
      $this->load->view('user/list_project',$data);
  }
  function edit_project($no_project){
    $sesi_user=array(
        'username' => $this->session->userdata('data_login')
      );
      $sesi_user_project=array(
        'no' => $no_project
      );
      $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
      $data["data_project"]=$this->user_model->get_project_user($sesi_user_project,'project_upload');
      $this->load->view('user/navbar_user',$data);
      $this->load->view('user/edit_project',$data);
  }
  function update_project($no_project){
    $sesi_user=array(
        'username' => $this->session->userdata('data_login')
      );
      $sesi_user_project=array(
        'no' => $no_project
      );
      $data['user']    = $this->user_model->get_data_user($sesi_user,'user_login');
      $data["data_project"]=$this->user_model->get_project_user($sesi_user_project,'project_upload');
      $this->form_validation->set_rules('name_project','Nama project','max_length[30]');
      $this->form_validation->set_rules('link','Link project','max_length[30]');
      $this->form_validation->set_rules('des_project','Deskripsi project','max_length[30]');
      if ($this->form_validation->run()){
          $where_edit=array(
            'no' => $no_project,
          );
          if (null ==! $this->input->post('name_project')){
            $data_edit=array(
              'nama_project'      => $this->input->post('name_project'),
            );
            $cek=$this->user_model->edit_project_user($data_edit,$where_edit,'project_upload');
          }if (null ==! $this->input->post('link')){
            $data_edit=array(
              'link_project'      => $this->input->post('link'),
            );
            $cek=$this->user_model->edit_project_user($data_edit,$where_edit,'project_upload');
          }
          if (null ==!$this->input->post('des_project')){
            $data_edit=array(
              'deskripsi_project'      => $this->input->post('des_project'),
            );
            $cek=$this->user_model->edit_project_user($data_edit,$where_edit,'project_upload');
          }

           $this->load->library('upload');
           $config['upload_path']   = "./upload_file/";
           $config['allowed_types'] = 'zip|rar';
           $config['max_size']      = '5000';
           $this->upload->initialize($config);
           if ($this->input->post('file_input') ==! TRUE){
           if ($this->upload->do_upload('file_input')){
             $data_edit=array(
               'name_file'      => $this->upload->data('file_name'),
             );
             $cek=$this->user_model->edit_project_user($data_edit,$where_edit,'project_upload');
          }
        }
        if ($cek !==FALSE){
          echo "<script>alert('Berhasil update data')</script>";
          echo "<meta http-equiv='refresh' content='0;url=".base_url('user/list_project')."'>";
        }else{
          echo "Tidak berhasil";
        }
      }
  }
  function del($project){
    $kontribusi=$this->user_model->get_kontribusi();
    foreach ($kontribusi as $value) {
      $get=$value->jumlah_kontribusi;
    }
    $kurangin=--$get;
    $kkk=array(
      'jumlah_kontribusi' => $kurangin
    );
    $data_project=array(
      'no' => $project
    );
    $s=$this->user_model->del_project($data_project,'project_upload');
    $r=$this->user_model->min_kontribusi($kkk,'user_login');
    if ($r !== FALSE AND $s !== FALSE){
    echo "<script>alert('Berhasil menghapus')</script>";
    echo "<meta http-equiv='refresh' content='0;url=".base_url('user/list_project')."'>";
        }else{
      echo "<script>alert('Sepertinya variabel pertama tidak menghasilkan true atau variabel kedua tidak menghasilkan true sehingga hasil yang dihasilkan oleh fungsi if adalah 0, kenapa ? karena fungsi if menggunakan logika AND, jika variabel pertama dan variabel kedua adalah true maka hasilnya akan true, jika sebaliknya maka akan false, deklarasi penggunaan if >> jika varibel a dan b tidak identik dengan string false makan akan menghasikan true, jika tidak maka akan false')</script>";
    }
  }
  function ganti_password(){
    $this->load->view('user/edit_password');
    return;
  }
  private function enc_pass($password){
    //Pake hash BCRYPT dengan algoritma CRYPT_BLOWFISH
    // return password_hash($password, PASSWORD_BCRYPT);
    // return $this->encryption->encrypt($password);
    /*
    * Using sha512 to encrypt user password
    * 2x encryption
    */
    $satu = hash('sha512',$password);
    return hash('sha512',$satu);
  }
  private function out_mendadak(){
    $this->session->sess_destroy();
    echo "<meta http-equiv='refresh' content='0;url=".base_url('login')."'>";
  }
  function proses_ganti_pass(){
    $this->form_validation->set_rules('pass','Password','required|max_length[20]');
    $this->form_validation->set_rules('re_pass','Ulangi password','required|matches[pass]');
    if ($this->form_validation->run()){

      $hashing=$this->enc_pass($this->input->post('re_pass'));

      $data_pass=array(
        'password' => $hashing
      );

      $cek=$this->user_model->ganti_password($data_pass,'user_login');

      if ($cek !== FALSE){
        $this->out_mendadak();
        echo "<script>alert('Anda kudu login lagi')</script>";
        echo "<meta http-equiv='refresh' content='0;url=".base_url('login')."'>";
      }else{
        echo "Sepertinya ada yang salah :) Kami akan memperbaikinya";
      }

    }else{
      $this->ganti_password();
    }
  }
}


/* End of file User.php */
/* Location /opt/lampp/htdocs/login-upload/application/controllers/User.php */

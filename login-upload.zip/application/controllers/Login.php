<?php
ob_start();
class Login extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('login_model');
    $this->load->library(array('form_validation','session','encryption'));
    if ($this->session->userdata('status_login')){
      redirect('user');
    }
  }
  function index(){
    $this->load->view('login/navbar');
    $this->load->view('login/login_view');
  }
  private function enc_pass($password){
    /*
    * Using sha512 to encrypt user password
    * 2x encryption
    */
    $satu = hash('sha512',$password);
    return hash('sha512',$satu);
  }

  function masuk(){
    $this->form_validation->set_rules('user','Username','required|min_length[3]|max_length[12]');
    $this->form_validation->set_rules('pass','Password','required|max_length[20]');
    if ($this->form_validation->run()){
      $hash=$this->enc_pass($this->input->post('pass'));
      $data=array(
        'username' => $this->input->post('user'),
        'password' => $hash
      );
      $get=$this->login_model->cek_login($data);
      if ($get->num_rows()){
        $data_sesi=array(
          'data_login'   => $this->input->post('user'),
          'status_login' => TRUE
        );
        $this->session->set_userdata($data_sesi);
        redirect('user');
      }else{
        $data["pesan"]="Username atau password salah";
        $this->load->view('login/navbar');
        $this->load->view('login/login_view',$data);
      }
    }else{
      $this->load->view('login/navbar');
      $this->load->view('login/login_view');
    }
  }
  function daftar(){
    $this->load->view('daftar/navbar');
    $this->load->view('daftar/daftar_view');
  }
  function proses_daftar(){
    date_default_timezone_set('Asia/Jakarta'); //Set default ke timzone indonesia
    $this->form_validation->set_rules('nama_lengkap','Nama lengkap','required|max_length[50]');
    $this->form_validation->set_rules('user','Username','required|alpha_numeric|max_length[12]');
    $this->form_validation->set_rules('pass','Password','required|max_length[12]');
    $this->form_validation->set_rules('re_pass','Ulangi password','required|matches[pass]|max_length[12]');
    $this->form_validation->set_rules('jenis_kelamin','Jenis kelamin','required');
    $this->form_validation->set_rules('email','Email','valid_email|max_length[50]');
    if ($this->form_validation->run()){
      $cek=$this->login_model->cek_user($this->input->post('user'));
      if (!$cek > 0){
      //Create primary key
      $date=date('Y-m-d');
      $time=date('H:i:s');
      $datetime=date('YmdHis');
      $na=strtolower(substr($this->input->post('nama_lengkap'),0,3));
      $sz=$na."-".str_shuffle($datetime);
      //Call variabel sz for primary key hahahaha
      //Using fungsi hash_pass
      $hash=$this->enc_pass($this->input->post('re_pass'));
      $daftar_data=array(
        'id'            => $sz,
        'nama_lengkap'  => $this->input->post('nama_lengkap'),
        'username'      => $this->input->post('user'),
        'password'      => $hash,
        'alamat_rumah'  => $this->input->post('adress'),
        'jenis_kelamin' => $this->input->post('jenis_kelamin'),
        'email'         => $this->input->post('email'),
        'tanggal_buat'  => $date,
        'waktu_buat'    => $time
      );
      $cek=$this->login_model->daftar_model($daftar_data,'user_login');
        if ($cek){
          $sesi_data=array(
            'data_login'   => $this->input->post('user'),
            'status_login' => TRUE
          );
          $this->session->set_userdata($sesi_data);
          redirect('user');
        }
      }else{
        echo "<script>alert('Username sudah ada silhkan pakai yang lain')</script>";
        echo "<meta http-equiv='refresh' content='3;url=".base_url('login')."'>";
      }
    }else{
      $this->load->view('daftar/navbar');
      $this->load->view('daftar/daftar_view');
    }
  }
}
/* End of file login.php
*  Location application/Controller/login.php
*/

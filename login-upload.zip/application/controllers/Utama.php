<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();

        /*
         *
         * Index page for this controller
         * Programmer : Joviandro
         * Database :  login-upload , Using Active record CI
         *
         */


class Utama extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('utama_model');
    $this->load->library(array('pagination','session'));

  }
  function index($id=NULL){
    $data["data_project"]=$this->utama_model->get_data();
    $total_rows=$this->utama_model->total_rows();

    $config['base_url']=base_url()."utama/index";
    $config['total_rows']=$total_rows;
    $config['per_page']=10;
    $config['first_page']='Awal';
    $config['last_page']='Akhir';
    $config['next_page']='>>';
    $config['prev_page']='<<';

    $config['full_tag_open'] = '<ul class="pagination">';
    $config['full_tag_close'] = '</ul>';
    $config['first_link'] = '&laquo; First';
    $config['first_tag_open'] = '<li class="prev page">';
    $config['first_tag_close'] = '</li>';

    $config['last_link'] = 'Last &raquo;';
    $config['last_tag_open'] = '<li class="next page">';
    $config['last_tag_close'] = '</li>';

    $config['next_link'] = 'Next &rarr;';
    $config['next_tag_open'] = '<li class="next page">';
    $config['next_tag_close'] = '</li>';

    $config['prev_link'] = '&larr; Prev';
    $config['prev_tag_open'] = '<li class="prev page">';
    $config['prev_tag_close'] = '</li>';

    $config['cur_tag_open'] = '<li class="current"><a href="">';
    $config['cur_tag_close'] = '</a></li>';

    $config['num_tag_open'] = '<li class="page">';
    $config['num_tag_close'] = '</li>';
    $this->pagination->initialize($config);

    $data['halaman']=$this->pagination->create_links();
    $data['query']=$this->utama_model->get_project($config['per_page'],$id);

    $this->load->view('halaman_utama/navbar');
    $this->load->view('halaman_utama/page_utama',$data);
  }
}

/* End of file Utama.php */
/* Location /opt/lampp/htdocs/login-upload/application/controllers/Utama.php */

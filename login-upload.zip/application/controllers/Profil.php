<?php
ob_start();
class Profil extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model(array('user_model','profil_model'));
    $this->load->library('session');
  }
  function user($user){
    $data_us=array(
      'username' => $user
    );
    $data_up=$user;
    $data['user']=$this->profil_model->get_all_data($data_up)->result();
    $this->load->view('halaman_utama/navbar');
    $this->load->view('profil/vw_profil',$data);
  }
}

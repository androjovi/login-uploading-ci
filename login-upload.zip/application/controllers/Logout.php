<?php
ob_start();
class Logout extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->library(array('session'));
  }
  function index(){
    $this->session->sess_destroy();
    echo "<script>alert('Berhasil logout')</script>";
    echo "<meta http-equiv='refresh' content='0;url=".base_url('login')."'>";
  }
}

<?php
class Utama_model extends CI_Model{
  function __construct(){
    parent::__construct();
  }
  function get_data(){
    return $this->db->get('project_upload')->result();
  }
  function total_rows(){
    $r=$this->db->get('project_upload');
    return $r->num_rows();
  }
  function get_project($num,$offset){
    $query=$this->db->get('project_upload',$num,$offset);
    return $query->result();
  }
  function hitung_cari($data){
    return;
  }
  function total_rows_cari($data){
    $this->db->like('nama_project',$data,'both');
    $r=$this->db->get('project_upload');
    return $r->num_rows();
  }
  function tampil_data($data,$num,$offset){
    $this->db->like('nama_project',$data,'both');
    $query=$this->db->get('project_upload',$num,$offset);
    return $query->result();
  }
}

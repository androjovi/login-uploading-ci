<?php
class User_model extends CI_Model{
  function __construct(){
    parent::__construct();
  }
  function get_data_user($where,$table){
    $this->db->where($where);
    $get=$this->db->get($table);
    return $get->result();
  }
  function get_project_user($where,$table){
    $this->db->where($where);
    $get=$this->db->get($table);
    return $get->result();
  }
  //For paging
  function get_project($num,$offset,$table){
    $this->db->where(array('uploader'=>$this->session->userdata('data_login')));
    $query=$this->db->get($table,$num,$offset);
    return $query->result();
  }
  //For paging
  function get_rows_project($where,$table){
    $this->db->where($where);
    $query=$this->db->get($table);
    return $query->num_rows();
  }
  function change_bg($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function change_bg_white($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function change_fp_none($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function edit_user($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function add_project_user($data,$table){
    $this->db->set($data);
    $this->db->insert($table);
    return;
  }
  function edit_project_user($data,$where,$table){
    $this->db->set($data);
    $this->db->where($where);
    $this->db->update($table);
    return;
  }
  function get_kontribusi(){
    $this->db->select('jumlah_kontribusi');
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $z=$this->db->get('user_login');
    return $z->result();
  }
  function add_kontribusi($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function min_kontribusi($data,$table){
    $this->db->set($data);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
    return;
  }
  function del_project($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
    return;
  }
  function ganti_password($where,$table){
    $this->db->set($where);
    $this->db->where(array('username'=>$this->session->userdata('data_login')));
    $this->db->update($table);
  }
}

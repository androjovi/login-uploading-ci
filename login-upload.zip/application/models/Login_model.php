<?php
class Login_model extends CI_Model{
  function __construct(){
    parent::__construct();
  }
  function cek_login($data_login){
    $this->db->where($data_login);
    return $this->db->get('user_login');
  }
  function cek_user($data){
    $this->db->where('username',$data);
    $query=$this->db->get('user_login');
    return $query->num_rows();
  }
  function daftar_model($data_daftar,$table){
    $this->db->set($data_daftar);
    $z=$this->db->insert($table);
    if ($z) // selalu ngasilin false
    return TRUE;
    else
    return FALSE;
  }
}

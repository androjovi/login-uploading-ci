<?php
class Profil_model extends CI_Model{
  function get_all_data($data){
    //Native
    return $this->db->query("SELECT * FROM project_upload AS pu JOIN user_login AS ul ON pu.uploader=ul.username WHERE uploader='".$data."'");
  }
}

<?php
class Upload_model extends CI_Model{
  function simpan_gambar($data){
  $this->db->set($data);
  $this->db->where(array('username'=>$this->session->userdata('data_login')));
  $this->db->update('user_login');
  return;
  }
}
